<?php

function js_debug($js)
{

	echo '<script>';
	echo "console.log('$js');";
	echo '</script>';


}

?>

